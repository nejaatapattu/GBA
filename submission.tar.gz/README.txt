Welcome to my game:
Help Squig (the white square) escape!

Aim of the game:
- Navigate Squig to the window to escape and win!
- If you touch the black hole, you fall in and lose :(
- You have 60 seconds to accomplish your task, otherwise it's game over.

How to play:
- Press enter to start playing.
- Use your arrow keys to move Squig around.
- Press backspace at any time to return to the start screen.



