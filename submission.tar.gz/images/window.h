/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 window window.png 
 * Time-stamp: Monday 04/03/2023, 13:55:48
 * 
 * Image Information
 * -----------------
 * window.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINDOW_H
#define WINDOW_H

extern const unsigned short window[100];
#define WINDOW_SIZE 200
#define WINDOW_LENGTH 100
#define WINDOW_WIDTH 10
#define WINDOW_HEIGHT 10

#endif

